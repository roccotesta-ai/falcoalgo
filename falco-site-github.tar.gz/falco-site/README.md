# Falco — Premium Multi‑Page Website (LuxAlgo‑Inspired)
Stack: Next.js (App Router) + TypeScript + Tailwind + Framer Motion + Recharts
Run:
```bash
npm i
npm run dev
```
