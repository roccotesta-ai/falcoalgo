export const metadata = { title: "Blog — Falco", description: "Content about Falco" };
export default function Page(){ return (<section className="w-full py-16"><div className="container-2xl">
  <h1 className="text-3xl font-bold">Blog</h1><div className="card mt-6">[PLACEHOLDER CONTENT]</div>
</div></section>); }
