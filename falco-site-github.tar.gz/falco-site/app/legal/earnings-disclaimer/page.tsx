export const metadata = { title: "Earnings Disclaimer — Falco", description: "Earnings Disclaimer for Falco" };
export default function Page(){ return (<section className="w-full py-16"><div className="container-2xl">
  <h1 className="text-3xl font-bold">Earnings Disclaimer</h1>
  <div className="card mt-6 prose prose-invert"><p>[PLACEHOLDER] Earnings Disclaimer content.</p>
  <p><strong>Disclaimer:</strong> Educational use only. Not investment advice. Past performance is not indicative of future results.</p></div>
</div></section>); }
